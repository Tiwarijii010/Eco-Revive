import React, { useState } from 'react';
import "./HomePage.css";

const HomePage = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <div>

      {/* Featured Categories */}
      <div className="categories">
        <div className="small-container">
          <div className="row ">
            <div className="col-3">
              <img src="/img/motorcontroller.jpeg" alt="" />
            </div>
            <div className="col-3">
              <img src="/img/ecomponet.jpeg" alt="" />
            </div>
            <div className="col-3">
              <img src="/img/solar charger.jpeg" alt="" />
            </div>
          </div>
        </div>
      </div>

      {/* Products */}
      <div className="small-container">
        <h2 className="heading">Featured Products</h2>
        <div className="row">
          <div className="col-4">
            <a href="/lead-battery"><img src="/img/Lead-Battery.jpg" alt="" /></a>
            <h4>Lead Acid Battery</h4>
            <div className="rating">
              <i className="fa fa-map-pin"></i>
            </div>
            <p>Min 40% Cheaper</p>
          </div>
          <div className="col-4">
            <div className="product-overlay">
              {/* Product Info */}
            </div>
            <a href="/Erick_battery"><img src="/img/100ah-electric-rickshaw-battery-250x250.webp" alt="" /></a>
            <h4>E-Rickshaw Battery</h4>
            <div className="rating">
              <i className="fa fa-map-pin"></i>
            </div>
            <p>Min 45% off!</p>
          </div>
          <div className="col-4">
            {/* Product Overlay */}
            <a href="/converter"><img src="/img/converter.jpg" alt="" /></a>
            <h4>Converter</h4>
            <div className="rating">
              <i className="fa fa-map-pin"></i>
            </div>
            <p>Sale 10% off</p>
          </div>
        </div>
        {/* Latest Electronics */}
        <h2 className="heading">Latest Electronics</h2>
        <div className="row">
          <div className="col-4">
            <img src="/img/accelerator.jpg" alt="" width="280px" height="270px" />
            <h4>Accelerator</h4>
            <div className="rating">
              <i className="fa fa-map-pin"></i>
            </div>
            <p>Buy Now!</p>
          </div>
          <div className="col-4">
            <img src="/img/controller refu..jpg" alt="" width="280px" height="270px" />
            <h4>Controller</h4>
            <div className="rating">
              <i className="fa fa-map-pin"></i>
            </div>
            <p>Fully Working!</p>
          </div>
          <div className="col-4">
            <img src="/img/electric-controller.jpg" alt="" width="280px" height="270px" />
            <h4>Electric Controller</h4>
            <div className="rating">
              <i className="fa fa-map-pin"></i>
            </div>
            <p>Limited Time Offer!</p>
          </div>
        </div>
        <div className="row">
          <div className="col-4">
            <img src="/img/chasis.jpg" alt="" width="280px" height="147px" />
            <h4>Chasis</h4>
            <div className="rating">
              <i className="fa fa-map-pin"></i>
            </div>
            <p>Only 2 left!</p>
          </div>
          <div className="col-4">
            <img src="/img/spare.jpg" alt="" width="280px" height="147px" />
            <h4>Spare Parts</h4>
            <div className="rating">
              <i className="fa fa-map-pin"></i>
            </div>
            <p>Limited Stock!</p>
          </div>
          <div className="col-4">
            <img src="/img/three phase motor.jpg" alt="" width="280px" height="147px" />
            <h4>Electric Controller</h4>
            <div className="rating">
              <i className="fa fa-map-pin"></i>
            </div>
            <p>Best Offers!</p>
          </div>
        </div>
      </div>

      {/* Offer */}
      <div className="offer">
        <div className="small-container">
          <div className="row">
            <div className="col-2">
              <img src="/img/rearmotorpart-bg.png" width="300px" height="510" alt="" />
            </div>
            <div className="col-2">
              <p>DTA K318319 2 Rear CV Axles</p>
              <h1>Motor Rear Axle with Controller</h1>
              <small>Heavy-duty OE replacement. Made to OE quality standard and performance.2008-2011 Kawasaki Teryx 750 Rear Left and Right Axles</small><br />
              <a href="#" className="btn">Buy Now &#8594; </a>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="footer" id="footer">
        <div className="container">
          <div className="row row-padding">
            <div className="foot-col-1">
              <h3>Download</h3>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus, repudiandae.</p>
              <div className="app-logo">
                <img src="" alt="AppleStore" />
                <img src="" alt="PlayStore" />
              </div>
            </div>
            <div className="foot-col-2">
              <img src="/img/logo.png" alt="img" />
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus, repudiandae.</p>
            </div>
            <div className="foot-col-3">
              <h3>Useful Links</h3>
              <ul>
                <li>Coupons</li>
                <li>Blog</li>
                <li>Return Policy</li>
                <li>Join Affiliate</li>
              </ul>
            </div>
            <div className="foot-col-4">
              <h3>Follow Us</h3>
              <ul>
                <li>Facebook</li>
                <li>Twitter</li>
                <li>Instagram</li>
                <li>Youtube</li>
              </ul>
            </div>
          </div>
          <hr />
          <p className="copyright">Copyright &copy; 2023</p>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
