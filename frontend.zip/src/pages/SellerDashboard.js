// src/pages/SellerDashboard.js

import React, { useEffect, useState } from 'react';
import axios from 'axios';
import config from '../config/config'

const SellerDashboard = () => {
  const [products, setProducts] = useState([]);
  const [editProduct, setEditProduct] = useState(null);
  const [updatedProduct, setUpdatedProduct] = useState({ name: '', description: '', price: '' });
  const [newProduct, setNewProduct] = useState({ name: '', description: '', price: '' });
  const [isAdding, setIsAdding] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null); // State for selected product

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get(`${config.apiUrl}/products/seller`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        setProducts(response.data);
      } catch (err) {
        console.error('Failed to fetch products', err);
      }
    };

    fetchProducts();
  }, []);

  const handleEditClick = (product) => {
    setEditProduct(product);
    setUpdatedProduct({ name: product.name, description: product.description, price: product.price });
  };

  const handleInputChange = (e, setProductFunc) => {
    const { name, value } = e.target;
    setProductFunc((prevProduct) => ({ ...prevProduct, [name]: value }));
  };

  const handleUpdateProduct = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.put(`${config.apiUrl}/products/${editProduct._id}`, updatedProduct, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setEditProduct(null);
      setProducts(products.map(product => 
        product._id === editProduct._id ? { ...product, ...updatedProduct } : product
      ));
    } catch (err) {
      console.error('Failed to update product', err);
    }
  };

  const handleAddProduct = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(`${config.apiUrl}/products/add`, newProduct, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setProducts([...products, response.data]);
      setNewProduct({ name: '', description: '', price: '' });
      setIsAdding(false);
    } catch (err) {
      console.error('Failed to add product', err);
    }
  };

  const handleProductClick = async (product) => {
    try {
      const response = await axios.get(`${config.apiUrl}/products/${product._id}`);
      setSelectedProduct(response.data);
    } catch (err) {
      console.error('Failed to fetch product details', err);
    }
  };

  const handleCloseModal = () => {
    setSelectedProduct(null);
  };

  return (
    <div>
      <h2>Seller Dashboard</h2>
      {products.length === 0 && (
        <div>
          <p>No products published yet.</p>
        </div>
      )}
      <div>
        <button onClick={() => setIsAdding(true)}>Add Product</button>
      </div>
      {products.length > 0 && (
        <div>
          <h3>Your Products</h3>
          <ul>
            {products.map((product) => (
              <li key={product._id}>
                <span onClick={() => handleProductClick(product)} style={{ cursor: 'pointer', textDecoration: 'underline' }}>
                  {product.name}
                </span>
                , <strong>Price:</strong> ${product.price}
                <button onClick={() => handleEditClick(product)}>Edit</button>
              </li>
            ))}
          </ul>
        </div>
      )}
      {isAdding && (
        <div>
          <h3>Add New Product</h3>
          <form onSubmit={handleAddProduct}>
            <label>
              Name:
              <input
                type="text"
                name="name"
                value={newProduct.name}
                onChange={(e) => handleInputChange(e, setNewProduct)}
                required
              />
            </label>
            <br />
            <label>
              Description:
              <input
                type="text"
                name="description"
                value={newProduct.description}
                onChange={(e) => handleInputChange(e, setNewProduct)}
                required
              />
            </label>
            <br />
            <label>
              Price:
              <input
                type="number"
                name="price"
                value={newProduct.price}
                onChange={(e) => handleInputChange(e, setNewProduct)}
                required
              />
            </label>
            <br />
            <button type="submit">Add Product</button>
            <button type="button" onClick={() => setIsAdding(false)}>Cancel</button>
          </form>
        </div>
      )}
      {editProduct && (
        <div>
          <h3>Edit Product</h3>
          <form onSubmit={handleUpdateProduct}>
            <label>
              Name:
              <input
                type="text"
                name="name"
                value={updatedProduct.name}
                onChange={(e) => handleInputChange(e, setUpdatedProduct)}
                required
              />
            </label>
            <br />
            <label>
              Description:
              <input
                type="text"
                name="description"
                value={updatedProduct.description}
                onChange={(e) => handleInputChange(e, setUpdatedProduct)}
                required
              />
            </label>
            <br />
            <label>
              Price:
              <input
                type="number"
                name="price"
                value={updatedProduct.price}
                onChange={(e) => handleInputChange(e, setUpdatedProduct)}
                required
              />
            </label>
            <br />
            <button type="submit">Update Product</button>
            <button type="button" onClick={() => setEditProduct(null)}>Cancel</button>
          </form>
        </div>
      )}
      {selectedProduct && (
        <div>
          <h3>Product Details</h3>
          <p><strong>Name:</strong> {selectedProduct.name}</p>
          <p><strong>Description:</strong> {selectedProduct.description}</p>
          <p><strong>Price:</strong> ${selectedProduct.price}</p>
          <p><strong>Published by:</strong> {selectedProduct.seller.name}</p>
          <button onClick={handleCloseModal}>Close</button>
        </div>
      )}
    </div>
  );
};

export default SellerDashboard;
