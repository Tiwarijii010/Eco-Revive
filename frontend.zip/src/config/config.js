const config = {
    apiUrl: 'http://localhost:8080/api', // Example URL; adjust as needed
  };
  
export default config;