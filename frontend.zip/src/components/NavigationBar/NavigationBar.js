import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FaUser, FaBars, FaTimes, FaShoppingCart } from 'react-icons/fa';
import './NavigationBar.css';

const NavigationBar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="navigation-bar">
      <div className="nav-container">
        <Link to="/" className="logo">
          <img src="/img/logo.png" alt="Company Logo" />
        </Link>
        <div className={`nav-links ${isMenuOpen ? 'active' : ''}`}>
          <Link to="/">Home</Link>
          <Link to="/products">Products</Link>
          <Link to="/about">About</Link>
          <a href="#footer" id="contact-link">Contact</a>
        </div>
        <div className="nav-icons">
          <div className="dropdown">
            <FaUser className="account-icon" />
            <div className="dropdown-content">
              <Link to="/login">Log In</Link>
              <Link to="/register">Register</Link>
              <Link to="/profile">My Profile</Link>
              <Link to="/wishlist">My Wishlist</Link>
              <Link to="/orders">My Orders</Link>
            </div>
          </div>
          <Link to="/cart" className="cart-icon">
            <FaShoppingCart />
          </Link>
        </div>
        <div className="menu-icon" onClick={toggleMenu}>
          {isMenuOpen ? <FaTimes /> : <FaBars />}
        </div>
      </div>
    </nav>
  );
};

export default NavigationBar;