// src/components/ProtectedRoute.js

import React from 'react';
import { Navigate } from 'react-router-dom';

const ProtectedRoute = ({ children, requiredType }) => {
  const userType = localStorage.getItem('userType');

  if (userType !== requiredType) {
    return <Navigate to="/" />;
  }

  return children;
};

export default ProtectedRoute;
