// src/components/Navbar.js

import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  const userType = localStorage.getItem('userType');

  return (
    <nav>
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        {userType === 'seller' && (
          <li>
            <Link to="/seller-dashboard">Seller Dashboard</Link>
          </li>
        )}
        {userType === 'buyer' && (
          <li>
            <Link to="/buyer-dashboard">Buyer Dashboard</Link>
          </li>
        )}
      </ul>
    </nav>
  );
};

export default Navbar;
