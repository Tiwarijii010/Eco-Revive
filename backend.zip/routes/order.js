// routes/order.js

const express = require('express');
const router = express.Router();
const { addOrder } = require('../controllers/orderController'); // Assuming you have an orderController

router.post('/add', addOrder); // Correctly defining the post route

module.exports = router;
