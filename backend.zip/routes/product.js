// routes/product.js

const express = require('express');
const router = express.Router();
const verifyToken = require('../middleware/authMiddleware');
const ProductController = require('../controllers/productController');
const Product = require('../models/Product');

// Protected route requiring authentication token
router.post('/add', verifyToken, ProductController.addProduct);


// Fetch all products
router.get('/', async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (err) {
    console.error('Failed to fetch products:', err);
    res.status(500).json({ message: 'Server error' });
  }
});


// Fetch products by seller
router.get('/seller', verifyToken, async (req, res) => {
    try {
      const products = await Product.find({ seller: req.user.id });
      res.json(products);
    } catch (err) {
      console.error('Failed to fetch seller products:', err);
      res.status(500).json({ message: 'Server error' });
    }
  });


// Update product details
router.put('/:id', verifyToken, async (req, res) => {
    const { name, description, price } = req.body;
    try {
      let product = await Product.findById(req.params.id);
  
      if (!product) {
        return res.status(404).json({ message: 'Product not found' });
      }
  
      // Ensure the product belongs to the seller making the request
      if (product.seller.toString() !== req.user.id) {
        return res.status(401).json({ message: 'Not authorized' });
      }
  
      product = await Product.findByIdAndUpdate(
        req.params.id,
        { name, description, price },
        { new: true }
      );
  
      res.json(product);
    } catch (err) {
      console.error('Failed to update product:', err);
      res.status(500).json({ message: 'Server error' });
    }
  });
module.exports = router;
