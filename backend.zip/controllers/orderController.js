// controllers/orderController.js

const Order = require('../models/Order');

const addOrder = async (req, res) => {
  const { productId, quantity } = req.body;

  if (!req.user || !req.user.id) {
    return res.status(401).json({ message: 'Unauthorized: No user found' });
  }

  const userId = req.user.id;

  try {
    const newOrder = new Order({ productId, quantity, user: userId });
    await newOrder.save();

    console.log('Order added successfully:', newOrder);
    res.status(201).json({ message: 'Order added successfully', order: newOrder });
  } catch (err) {
    console.error('Failed to add order:', err);
    res.status(500).json({ message: 'Failed to add order', error: err.message });
  }
};

module.exports = {
  addOrder,
};
