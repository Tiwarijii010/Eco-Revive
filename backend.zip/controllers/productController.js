// controllers/productController.js

const Product = require('../models/Product');

const addProduct = async (req, res) => {
  const { name, description, price } = req.body;
  const seller = req.user.id; // Assuming req.user has the authenticated user's ID

  try {
    const newProduct = new Product({ name, description, price, seller });
    await newProduct.save();
    console.log('Product added successfully:', newProduct);
    res.status(201).json({ message: 'Product added successfully', product: newProduct });
  } catch (err) {
    console.error('Failed to add product:', err);
    res.status(500).json({ message: 'Failed to add product', error: err.message });
  }
};

module.exports = {
  addProduct,
};
